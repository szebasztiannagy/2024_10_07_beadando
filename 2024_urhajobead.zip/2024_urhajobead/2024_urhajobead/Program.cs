﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2024_urhajobead
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Urbazis urbazis = new Urbazis(22);
            urbazis.Megjelenit();
            urbazis.Simulal();
            Console.ReadLine();
        }
    }
}
